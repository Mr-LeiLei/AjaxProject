package com.cwnu.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cwnu.dao.ContentDao;
import com.cwnu.dao.impl.ContentDaoImpl;
import com.cwnu.pojo.Content;

//获取所有留言消息
@WebServlet("/GetContextServlet")
public class GetContextServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//设置字符编码规则
		response.setContentType("text/html;charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		ContentDao dao = new ContentDaoImpl();
		//获取所有数据
		List<Content> allContent = dao.getAllContent();
		//System.out.println(allContent);
		//将查询到的数据发送给页面
		response.getWriter().append(allContent.toString());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//调用上面doGet方法
		doGet(request, response);
	}

}
