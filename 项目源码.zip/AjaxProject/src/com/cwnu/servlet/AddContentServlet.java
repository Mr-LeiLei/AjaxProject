package com.cwnu.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cwnu.dao.ContentDao;
import com.cwnu.dao.impl.ContentDaoImpl;
import com.cwnu.pojo.Content;

//添加留言数据接口
@WebServlet("/AddContentServlet")
public class AddContentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//设置字符编码规则
		request.setCharacterEncoding("UTF-8");
		//获取表单传过来数据
		String name = request.getParameter("name");
		String content = request.getParameter("content");
		ContentDao dao = new ContentDaoImpl();
		//创建Content对象
		Content con = new Content();
		con.setName(name);
		con.setContent(content);
		//添加内容
		dao.addContent(con);
		//添加成功标志
		response.getWriter().append("true");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//调用上面doGet方法
		doGet(request, response);
	}

}
