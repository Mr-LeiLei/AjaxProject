package com.cwnu.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cwnu.dao.ContentDao;
import com.cwnu.pojo.Content;
import com.cwnu.util.JDBCUtils;

// 留言数据持久化接口实例化
public class ContentDaoImpl implements ContentDao {

	//创建数据库连接对象
	Connection conn = null;
	PreparedStatement pstmt = null;
	
	//添加数据信息
	@Override
	public void addContent(Content content) {
		try {
			//打开数据库连接
			conn = JDBCUtils.getConnection();
			String sql = "insert into content(name,content) values(?,?)";
			//预编译SQL语句
			pstmt = conn.prepareStatement(sql);
			//传入参数
			pstmt.setString(1, content.getName());
			pstmt.setString(2, content.getContent());
			//执行SQL
			pstmt.execute();
			//关闭连接
			JDBCUtils.closeAll(pstmt, conn);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//获取所有留言数据
	@Override
	public List<Content> getAllContent() {
		//创建一个集合用户保存查询的留言
		List<Content> list=new ArrayList<>();
		try {
			//打开数据库连接
			conn = JDBCUtils.getConnection();
			String sql="select * from content";
			//预编译SQL文件
			pstmt = conn.prepareStatement(sql);
			//执行SQL
			ResultSet rs = pstmt.executeQuery();
			//循环遍历查询的数据放入list集合
			while(rs.next()) {
				int id = rs.getInt(1);
				String name=rs.getString(2);
				String content=rs.getString(3);
				Content con = new Content(id,name,content);
				list.add(con);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		//关闭连接 
		JDBCUtils.closeAll(pstmt, conn);
		return list;
	}

}
