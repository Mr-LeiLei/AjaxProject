package com.cwnu.dao;

import java.util.List;

import com.cwnu.pojo.Content;

// 持久化留言数据接口
public interface ContentDao {

	//添加留言数据
	void addContent(Content content);
	
	//获取所有留言数据信息
	List<Content> getAllContent();
}
